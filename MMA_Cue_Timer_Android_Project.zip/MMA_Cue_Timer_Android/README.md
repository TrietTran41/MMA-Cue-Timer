# MMA Cue Timer — Android app

A standalone Android wrapper for the MMA shadowboxing cue timer.

## App behavior
- Native Android app icon / launcher entry
- Works offline after installation
- Normal drill mode with adjustable round count, round length, rest, and random cue delay
- One-tap Fight Simulation mode: defaults to 3 × 3-minute rounds with 1-minute rests
- Fight Simulation timing and cue-delay settings are separately configurable and saved on the phone
- Right-side preset: CROSS / TEEP / CALF KICK / SHOOT
- Left-side preset: JAB / LEAD TEEP / LEAD CALF KICK / SINGLE
- Custom cues
- Native Android TextToSpeech
- Keeps the phone screen awake while the app is open
- Portrait orientation
- Distraction-free round screen: only timer + visual cue
- 3-second 3/2/1 beep countdown before every round
- Distinct double-clap alert at 10 seconds remaining
- Tap training screen to pause/resume; hold ~1 second to return to setup
- Immersive Android system UI during training

## Build in Android Studio
1. Open this folder in Android Studio.
2. Let Android Studio install/resolve SDK 35 if prompted.
3. Build > Build APK(s).
4. Install `app-debug.apk` on the phone.

## Build automatically with GitHub Actions
The included `.github/workflows/build-apk.yml` builds an installable debug APK.
Push the project to a GitHub repository, open the Actions tab, run "Build Android APK",
then download the `MMA-Cue-Timer-APK` artifact.

No Play Store account is required for a debug APK you install on your own Android phone.

## v1.5 additions
- Dedicated FIGHT SIMULATION button.
- Fight Simulation defaults to 3 rounds × 3 minutes with 60-second rests.
- Fight Simulation has its own saved round/rest/cue-delay settings.
- Uses the currently selected preset and active cues with protected random calling.
- Existing distraction-free countdown, 10-second clap alert, and end-of-session cue summary remain active in Fight Simulation.
- RUN AGAIN repeats the exact session type and configuration that just finished.

## v1.4 additions
- Protected-random cue calling: outcomes can be uneven and repeats are allowed.
- The session is planned randomly but guarantees every active cue finishes at 10% or more of total cue calls.
- Maximum 10 active cues because a strict 10% floor cannot be guaranteed above 10 cues.
- End-of-session summary showing total cues and count/percentage for every active cue.


## v1.6 voice speed
Voice speed is adjustable from 0.75x to 2.00x and saved on-device. Default is 1.35x.

# MMA Cue Timer — Android app

A standalone Android wrapper for the MMA shadowboxing cue timer.

## App behavior
- Native Android app icon / launcher entry
- Works offline after installation
- Normal drill mode with adjustable round count, round length, rest, and random cue delay
- One-tap Fight Simulation mode: defaults to 3 × 3-minute rounds with 1-minute rests
- Fight Simulation timing and cue-delay settings are separately configurable and saved on the phone
- Right-side preset: CROSS / TEEP / CALF KICK / SHOOT
- Left-side preset: JAB / LEAD TEEP / LEAD CALF KICK / SINGLE
- Custom cues
- Native Android TextToSpeech
- Keeps the phone screen awake while the app is open
- Portrait orientation
- Distraction-free round screen: only timer + visual cue
- Universal 3/2/1 short-beep countdown before every round, followed by a long round-start beep
- Universal long beep when every round ends
- Distinct double-clap alert at 10 seconds remaining
- Tap training screen to pause/resume; hold ~1 second to return to setup
- Immersive Android system UI during training

## Build in Android Studio
1. Open this folder in Android Studio.
2. Let Android Studio install/resolve SDK 35 if prompted.
3. Build > Build APK(s).
4. Install `app-debug.apk` on the phone.

## Build automatically with GitHub Actions
The included `.github/workflows/build-apk.yml` builds an installable debug APK.
Push the project to a GitHub repository, open the Actions tab, run "Build Android APK",
then download the `MMA-Cue-Timer-APK` artifact.

No Play Store account is required for a debug APK you install on your own Android phone.

## v1.5 additions
- Dedicated FIGHT SIMULATION button.
- Fight Simulation defaults to 3 rounds × 3 minutes with 60-second rests.
- Fight Simulation has its own saved round/rest/cue-delay settings.
- Uses the currently selected preset and active cues with protected random calling.
- Existing distraction-free countdown, 10-second clap alert, and end-of-session cue summary remain active in Fight Simulation.
- RUN AGAIN repeats the exact session type and configuration that just finished.

## v1.4 additions
- Protected-random cue calling: outcomes can be uneven and repeats are allowed.
- The session is planned randomly but guarantees every active cue finishes at 10% or more of total cue calls.
- Maximum 10 active cues because a strict 10% floor cannot be guaranteed above 10 cues.
- End-of-session summary showing total cues and count/percentage for every active cue.


## v1.6 voice speed
Voice speed is adjustable from 0.75x to 2.00x and saved on-device. Default is 1.35x.

## v1.7 cue percentages
- Every active cue now has a configurable target percentage.
- Each active cue must be at least 10%, and active percentages must total exactly 100% before a session can start.
- Cue order remains random, including possible repeats/clusters.
- The app plans the whole session using weighted quotas, so the final distribution lands as close to the requested percentages as whole cue calls allow.
- Session summary now shows actual percentage beside the configured target percentage.
- Added an EVEN SPLIT ACTIVE CUES helper for quickly resetting a preset to equal shares.


## v1.8 session history
- Completed sessions are saved locally on the phone.
- Keeps the newest 20 sessions; saving session 21 automatically deletes the oldest.
- History stores session type, preset name, timing settings, total cue count, each cue count, actual percentage, and target percentage.
- History is newest-first and can be reviewed from the setup screen.


## v1.9 bike intervals + universal round horn
- Added a dedicated BIKE INTERVAL mode.
- Bike workout structure is fixed at 3 × 3-minute rounds with 1-minute rests.
- Bike pacing alternates HARD and CHILL; every round starts on HARD.
- HARD + CHILL always equals one 30-second cycle. Configure HARD from 1–29 seconds and CHILL automatically becomes the remainder.
- Bike training view shows the 3-minute round clock, HARD/CHILL state, and the current interval countdown.
- HARD/CHILL transitions are spoken so the bike can be used without staring at the phone.
- Drill, Fight Simulation, and Bike now all use 3/2/1 short beeps followed by a long start beep, plus a long beep at round end.
- The existing clap-clap warning at 10 seconds remaining stays active in all three modes.
- Bike sessions get a simple completion summary; the 20-session percentage history remains focused on cue-based Drill/Fight sessions.

# MMA Cue Timer — Android app

A standalone Android wrapper for the MMA shadowboxing cue timer.

## App behavior
- Native Android app icon / launcher entry
- Works offline after installation
- 3 × 3-minute default rounds
- Adjustable round count, round length, rest, and random cue delay
- Right-side preset: CROSS / TEEP / CALF KICK / SHOOT
- Left-side preset: JAB / LEAD TEEP / LEAD CALF KICK / SINGLE
- Custom cues
- Native Android TextToSpeech
- Keeps the phone screen awake while the app is open
- Portrait orientation
- Distraction-free round screen: only timer + visual cue
- 3-second 3/2/1 beep countdown before every round
- Distinct double-clap alert at 10 seconds remaining
- Tap training screen to pause/resume; hold ~1 second to return to setup
- Immersive Android system UI during training

## Build in Android Studio
1. Open this folder in Android Studio.
2. Let Android Studio install/resolve SDK 35 if prompted.
3. Build > Build APK(s).
4. Install `app-debug.apk` on the phone.

## Build automatically with GitHub Actions
The included `.github/workflows/build-apk.yml` builds an installable debug APK.
Push the project to a GitHub repository, open the Actions tab, run "Build Android APK",
then download the `MMA-Cue-Timer-APK` artifact.

No Play Store account is required for a debug APK you install on your own Android phone.

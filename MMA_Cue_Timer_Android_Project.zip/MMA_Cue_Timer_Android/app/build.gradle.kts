plugins {
    id("com.android.application")
}

android {
    namespace = "com.mmacuetimer.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.mmacuetimer.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 6
        versionName = "1.5"
    }

    signingConfigs {
        create("persistentDebug") {
            storeFile = file("mmacue-debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("persistentDebug")
        }
    }
}

dependencies {
}
